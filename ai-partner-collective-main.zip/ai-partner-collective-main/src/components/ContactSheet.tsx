import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import {
  Sheet,
  SheetContent,
  SheetDescription,
  SheetHeader,
  SheetTitle,
  SheetTrigger,
} from "@/components/ui/sheet";
import { toast } from "sonner";

interface ContactSheetProps {
  trigger: React.ReactNode;
}

export const ContactSheet = ({ trigger }: ContactSheetProps) => {
  const [isOpen, setIsOpen] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    firma: "",
    useCase: "",
    message: "",
  });

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);

    // Create mailto link with form data
    const subject = encodeURIComponent(`Beratungsanfrage von ${formData.firma}`);
    const body = encodeURIComponent(
      `Name: ${formData.name}\nE-Mail: ${formData.email}\nFirma: ${formData.firma}\nUse Case: ${formData.useCase}\n\nNachricht:\n${formData.message}`
    );
    
    window.location.href = `mailto:infrasenseai@gmail.com?subject=${subject}&body=${body}`;
    
    toast.success("E-Mail-Client wird geöffnet...");
    setIsSubmitting(false);
    setIsOpen(false);
    setFormData({ name: "", email: "", firma: "", useCase: "", message: "" });
  };

  return (
    <Sheet open={isOpen} onOpenChange={setIsOpen}>
      <SheetTrigger asChild>{trigger}</SheetTrigger>
      <SheetContent className="w-full sm:max-w-lg overflow-y-auto">
        <SheetHeader>
          <SheetTitle className="text-2xl">Beratung anfragen</SheetTitle>
          <SheetDescription>
            Erzählen Sie uns von Ihrem Projekt. Wir melden uns innerhalb von 24 Stunden.
          </SheetDescription>
        </SheetHeader>

        <form onSubmit={handleSubmit} className="space-y-6 mt-8">
          <div className="space-y-2">
            <Label htmlFor="name">Name *</Label>
            <Input
              id="name"
              placeholder="Max Mustermann"
              value={formData.name}
              onChange={(e) => setFormData({ ...formData, name: e.target.value })}
              required
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="email">E-Mail *</Label>
            <Input
              id="email"
              type="email"
              placeholder="max@beispiel.de"
              value={formData.email}
              onChange={(e) => setFormData({ ...formData, email: e.target.value })}
              required
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="firma">Firma *</Label>
            <Input
              id="firma"
              placeholder="Ihre Firma GmbH"
              value={formData.firma}
              onChange={(e) => setFormData({ ...formData, firma: e.target.value })}
              required
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="useCase">Use Case *</Label>
            <Input
              id="useCase"
              placeholder="z.B. Automatisierung des Kundensupports"
              value={formData.useCase}
              onChange={(e) => setFormData({ ...formData, useCase: e.target.value })}
              required
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="message">Nachricht</Label>
            <Textarea
              id="message"
              placeholder="Beschreiben Sie Ihr Projekt oder Ihre Anforderungen..."
              rows={4}
              value={formData.message}
              onChange={(e) => setFormData({ ...formData, message: e.target.value })}
            />
          </div>

          <Button type="submit" className="w-full" size="lg" disabled={isSubmitting}>
            {isSubmitting ? "Wird gesendet..." : "Anfrage senden"}
          </Button>
        </form>
      </SheetContent>
    </Sheet>
  );
};
