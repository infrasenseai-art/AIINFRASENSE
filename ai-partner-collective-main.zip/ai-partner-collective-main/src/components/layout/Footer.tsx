import { Phone } from "lucide-react";

export const Footer = () => {
  return (
    <footer className="py-8 border-t border-border/30">
      <div className="container">
        <div className="flex flex-col md:flex-row justify-between items-center gap-4">
          <span className="text-muted-foreground">
            © 2026 Infrasenseai – Alle Rechte vorbehalten.
          </span>

          <div className="flex items-center gap-4 text-sm">
            <a
              href="tel:+493042431551"
              className="flex items-center gap-2 text-primary hover:text-primary/80 transition-colors"
            >
              <Phone className="w-4 h-4" />
              +49 30 42431551
            </a>
            <span className="text-muted-foreground">·</span>
            <a
              href="#impressum"
              className="text-primary hover:text-primary/80 transition-colors"
            >
              Impressum
            </a>
            <span className="text-muted-foreground">·</span>
            <a
              href="#datenschutz"
              className="text-primary hover:text-primary/80 transition-colors"
            >
              Datenschutz
            </a>
          </div>
        </div>
      </div>
    </footer>
  );
};