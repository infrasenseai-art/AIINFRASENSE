import { motion } from "framer-motion";
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";

const faqs = [
  {
    question: "Ist die Lösung DSGVO-konform?",
    answer: "Ja, alle unsere Lösungen sind vollständig DSGVO-konform. Wir arbeiten ausschließlich mit europäischen Rechenzentren und stellen sicher, dass alle Datenverarbeitungsprozesse den strengen europäischen Datenschutzrichtlinien entsprechen.",
  },
  {
    question: "Wo werden Daten verarbeitet?",
    answer: "Ihre Daten werden ausschließlich in zertifizierten Rechenzentren in der EU verarbeitet. Wir setzen auf redundante Systeme und regelmäßige Sicherheitsaudits, um höchste Verfügbarkeit und Datensicherheit zu gewährleisten.",
  },
  {
    question: "Wie sieht es mit dem EU AI Act aus?",
    answer: "Wir beobachten die Entwicklungen des EU AI Acts genau und passen unsere Lösungen proaktiv an die neuen Anforderungen an. Unsere KI-Assistenten sind so konzipiert, dass sie transparent und nachvollziehbar arbeiten.",
  },
  {
    question: "Wie starte ich am schnellsten?",
    answer: "Der schnellste Weg ist ein kostenloses Erstgespräch. In 30 Minuten analysieren wir Ihre aktuellen Prozesse und zeigen Ihnen konkrete Optimierungspotenziale.",
  },
];

export const FAQ = () => {
  return (
    <section id="faq" className="py-32">
      <div className="container max-w-3xl">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8 }}
          className="text-center mb-16"
        >
          <h2 className="font-display text-4xl md:text-5xl lg:text-6xl font-bold tracking-tight mb-6">
            Häufige Fragen
          </h2>
          <p className="text-muted-foreground text-xl font-light">
            Transparenz und Datenschutz sind uns wichtig.
          </p>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6, delay: 0.1 }}
        >
          <Accordion type="single" collapsible className="space-y-4">
            {faqs.map((faq, index) => (
              <AccordionItem
                key={index}
                value={`item-${index}`}
                className="bg-secondary/30 rounded-2xl px-8 border-none"
              >
                <AccordionTrigger className="text-left text-lg font-medium hover:no-underline py-6">
                  {faq.question}
                </AccordionTrigger>
                <AccordionContent className="text-muted-foreground pb-6 text-base leading-relaxed font-light">
                  {faq.answer}
                </AccordionContent>
              </AccordionItem>
            ))}
          </Accordion>
        </motion.div>
      </div>
    </section>
  );
};
