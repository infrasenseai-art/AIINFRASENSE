import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";
import { ContactSheet } from "@/components/ContactSheet";
import mascot from "@/assets/mascot.png";

export const Hero = () => {
  return (
    <section className="relative min-h-screen flex items-center justify-center py-32 overflow-hidden">
      {/* Subtle background gradient */}
      <div className="absolute inset-0 bg-gradient-to-b from-primary/3 via-transparent to-transparent" />
      
      <div className="container relative z-10">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
          {/* Text content */}
          <motion.div
            initial={{ opacity: 0, x: -40 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 1, ease: "easeOut" }}
            className="text-left"
          >
            {/* Title - Apple style large text */}
            <h1 className="font-display text-5xl md:text-6xl lg:text-7xl font-bold mb-8 tracking-tight leading-[1.1]">
              <span className="text-foreground">KI-Beratung</span>
              <br />
              <span className="text-gradient">für Ihr Business.</span>
            </h1>

            {/* Subtitle - cleaner, more spacious */}
            <p className="text-muted-foreground text-xl md:text-2xl max-w-xl mb-12 leading-relaxed font-light">
              Wir automatisieren Ihre Prozesse mit intelligenten Workflows 
              und KI – für messbar bessere Ergebnisse.
            </p>

            {/* CTA Buttons */}
            <motion.div
              className="flex flex-col sm:flex-row gap-4"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.5 }}
            >
              <ContactSheet 
                trigger={
                  <Button variant="hero" size="lg" className="text-base px-8">
                    Beratung anfragen
                  </Button>
                }
              />
              <Button 
                variant="heroOutline" 
                size="lg" 
                className="text-base px-8"
                onClick={() => document.getElementById('leistungen')?.scrollIntoView({ behavior: 'smooth' })}
              >
                Mehr erfahren
              </Button>
            </motion.div>
          </motion.div>

          {/* Mascot */}
          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 1, delay: 0.3, ease: "easeOut" }}
            className="hidden lg:flex justify-center items-center"
          >
            <motion.img
              src={mascot}
              alt="Infrasenseai Mascot"
              className="w-[400px] h-auto drop-shadow-2xl"
              animate={{ y: [0, -15, 0] }}
              transition={{ duration: 4, repeat: Infinity, ease: "easeInOut" }}
            />
          </motion.div>
        </div>
      </div>
    </section>
  );
};
