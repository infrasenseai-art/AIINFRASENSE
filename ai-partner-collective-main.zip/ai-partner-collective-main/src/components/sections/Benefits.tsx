import { motion } from "framer-motion";
import { Lightbulb, Users, Layers, TrendingUp } from "lucide-react";

const benefits = [
  {
    icon: Lightbulb,
    title: "Strategische Beratung",
    description: "Von der Analyse bis zur Implementierung – wir begleiten Sie auf dem Weg zur KI-Integration.",
  },
  {
    icon: Users,
    title: "Team Enablement",
    description: "Wissenstransfer und Schulungen, damit Ihr Team die Lösungen eigenständig weiterentwickelt.",
  },
  {
    icon: Layers,
    title: "Maßgeschneiderte Lösungen",
    description: "Individuelle Automatisierungen, die genau zu Ihren Geschäftsprozessen passen.",
  },
  {
    icon: TrendingUp,
    title: "Messbare Ergebnisse",
    description: "Kürzere Bearbeitungszeiten, höhere Effizienz und zufriedenere Kunden.",
  },
];

export const Benefits = () => {
  return (
    <section id="vorteile" className="py-32">
      <div className="container max-w-6xl">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8 }}
          className="text-center mb-20"
        >
          <h2 className="font-display text-4xl md:text-5xl lg:text-6xl font-bold mb-6 tracking-tight">
            Warum Infrasenseai?
          </h2>
          <p className="text-muted-foreground text-xl max-w-2xl mx-auto font-light">
            Wir verbinden technische Expertise mit strategischem Verständnis.
          </p>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 lg:gap-12">
          {benefits.map((benefit, index) => (
            <motion.div
              key={benefit.title}
              initial={{ opacity: 0, y: 40 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6, delay: index * 0.1 }}
              className="group p-8 rounded-3xl bg-secondary/30 hover:bg-secondary/50 transition-all duration-500"
            >
              <div className="text-primary mb-6">
                <benefit.icon className="w-10 h-10 stroke-[1.5]" />
              </div>

              <h3 className="font-display text-2xl font-semibold mb-4">{benefit.title}</h3>
              <p className="text-muted-foreground text-lg leading-relaxed font-light">
                {benefit.description}
              </p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};
