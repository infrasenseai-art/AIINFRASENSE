import { motion } from "framer-motion";
import { Target, Settings, Cpu, Rocket } from "lucide-react";

const steps = [
  {
    number: "01",
    icon: Target,
    title: "Analyse & Strategie",
    description: "Wir verstehen Ihre Prozesse und definieren gemeinsam klare Ziele.",
  },
  {
    number: "02",
    icon: Settings,
    title: "Konzeption",
    description: "Individuelle Lösungsarchitektur, abgestimmt auf Ihre Systeme.",
  },
  {
    number: "03",
    icon: Cpu,
    title: "Implementierung",
    description: "Agile Umsetzung mit regelmäßigem Feedback und transparenter Kommunikation.",
  },
  {
    number: "04",
    icon: Rocket,
    title: "Launch & Support",
    description: "Go-Live, Schulung und kontinuierliche Optimierung Ihrer Lösung.",
  },
];

export const Process = () => {
  return (
    <section id="ablauf" className="py-32">
      <div className="container max-w-6xl">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8 }}
          className="text-center mb-20"
        >
          <h2 className="font-display text-4xl md:text-5xl lg:text-6xl font-bold mb-6 tracking-tight">
            In 4 Schritten zum Erfolg
          </h2>
          <p className="text-muted-foreground text-xl max-w-2xl mx-auto font-light">
            Ein klarer Prozess für messbare Ergebnisse.
          </p>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {steps.map((step, index) => (
            <motion.div
              key={step.title}
              initial={{ opacity: 0, y: 40 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6, delay: index * 0.1 }}
              className="relative text-center"
            >
              {/* Number */}
              <div className="text-6xl font-display font-bold text-primary/20 mb-4">
                {step.number}
              </div>

              <div className="inline-flex items-center justify-center w-12 h-12 rounded-full bg-primary/10 text-primary mb-6">
                <step.icon className="w-6 h-6 stroke-[1.5]" />
              </div>

              <h3 className="font-display text-xl font-semibold mb-3">{step.title}</h3>
              <p className="text-muted-foreground leading-relaxed font-light">
                {step.description}
              </p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};
