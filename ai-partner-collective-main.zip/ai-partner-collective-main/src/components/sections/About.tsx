import { motion } from "framer-motion";
import { Linkedin } from "lucide-react";
import superchatLogo from "@/assets/superchat-logo.png";
import fonioLogo from "@/assets/fonio-logo.avif";

const founders = [
  {
    name: "Gianluca Lo Greco",
    linkedin: "https://www.linkedin.com/in/gianluca-lo-greco-800831294/",
  },
  {
    name: "David Rignanese Reyes",
    linkedin: "https://www.linkedin.com/in/david-rignanese-reyes/",
  },
];

export const About = () => {
  return (
    <section id="ueber-uns" className="py-32 bg-secondary/20">
      <div className="container max-w-4xl">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8 }}
          className="text-center mb-16"
        >
          <h2 className="font-display text-4xl md:text-5xl lg:text-6xl font-bold tracking-tight mb-6">
            Über uns
          </h2>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8, delay: 0.1 }}
          className="text-center mb-16"
        >
          <p className="text-muted-foreground text-xl leading-relaxed font-light max-w-3xl mx-auto">
            Wir sind Infrasenseai – eine Agentur, die Unternehmen dabei unterstützt, ihre Prozesse radikal zu optimieren. 
            Mit smarter Automatisierung, KI und innovativer Kommunikation sorgen wir dafür, dass unsere Kunden mehr erreichen 
            mit weniger Aufwand.
          </p>
        </motion.div>

        {/* Founders */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6, delay: 0.2 }}
          className="text-center mb-16"
        >
          <h3 className="font-display text-xl font-semibold mb-8">Gründer</h3>
          <div className="flex flex-wrap justify-center gap-6">
            {founders.map((founder) => (
              <a
                key={founder.name}
                href={founder.linkedin}
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center gap-3 bg-secondary/50 rounded-full px-6 py-3 hover:bg-primary/10 transition-colors group"
              >
                <Linkedin className="w-5 h-5 text-primary" />
                <span className="font-medium group-hover:text-primary transition-colors">
                  {founder.name}
                </span>
              </a>
            ))}
          </div>
        </motion.div>

        {/* Partners */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6, delay: 0.3 }}
          className="text-center"
        >
          <h3 className="font-display text-xl font-semibold mb-8">Unsere Partner</h3>
          <div className="flex flex-wrap justify-center items-center gap-12">
            <img
              src={superchatLogo}
              alt="Superchat"
              className="h-10 opacity-70 hover:opacity-100 transition-opacity"
            />
            <img
              src={fonioLogo}
              alt="Fonio"
              className="h-10 opacity-70 hover:opacity-100 transition-opacity"
            />
          </div>
        </motion.div>
      </div>
    </section>
  );
};
