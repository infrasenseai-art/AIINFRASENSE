import { motion } from "framer-motion";
import { MessageSquare, Workflow, Bot } from "lucide-react";

const services = [
  {
    icon: MessageSquare,
    title: "Kommunikation",
    subtitle: "Omnichannel-Integration",
    description: "WhatsApp, E-Mail und Webchat zentral gesteuert – mit intelligenten Routing-Regeln und Vorlagen.",
  },
  {
    icon: Workflow,
    title: "Automatisierung",
    subtitle: "Workflow-Optimierung",
    description: "Von der Ticketbearbeitung bis zum Reporting – zuverlässige Prozesse, die mitwachsen.",
  },
  {
    icon: Bot,
    title: "KI-Assistenz",
    subtitle: "Intelligente Unterstützung",
    description: "Chatbots und Antwortvorschläge mit nahtloser Übergabe an Ihre Mitarbeiter.",
  },
];

export const Services = () => {
  return (
    <section id="leistungen" className="py-32 bg-secondary/20">
      <div className="container max-w-6xl">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8 }}
          className="text-center mb-20"
        >
          <h2 className="font-display text-4xl md:text-5xl lg:text-6xl font-bold mb-6 tracking-tight">
            Unsere Leistungen
          </h2>
          <p className="text-muted-foreground text-xl max-w-2xl mx-auto font-light">
            Drei Säulen für Ihre digitale Transformation.
          </p>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {services.map((service, index) => (
            <motion.div
              key={service.title}
              initial={{ opacity: 0, y: 40 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6, delay: index * 0.15 }}
              className="group text-center p-10 rounded-3xl bg-card/50 border border-border/30 hover:border-primary/30 transition-all duration-500"
            >
              <div className="inline-flex items-center justify-center w-16 h-16 rounded-2xl bg-primary/10 text-primary mb-8">
                <service.icon className="w-8 h-8 stroke-[1.5]" />
              </div>

              <p className="text-primary text-sm font-medium uppercase tracking-wider mb-2">
                {service.subtitle}
              </p>
              <h3 className="font-display text-2xl font-semibold mb-4">{service.title}</h3>
              <p className="text-muted-foreground leading-relaxed font-light">
                {service.description}
              </p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};
