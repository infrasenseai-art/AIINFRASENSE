import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";
import { ContactSheet } from "@/components/ContactSheet";
import { Star, Quote } from "lucide-react";

const testimonials = [
  {
    quote: "Mit dem Assistenten beantworten wir Standardfragen automatisch – z. B. Öffnungszeiten, Verträge und Kursbuchungen. Unsere Mitglieder bekommen in Sekunden Hilfe und das Team hat wieder Zeit fürs Studio.",
    author: "Leon R.",
    role: "Operations Manager, Fitnessstudio-Kette",
  },
  {
    quote: "Im E-Commerce hat der Assistent Tickets zu Lieferstatus und Retouren um über 40 % reduziert. Die Übergabe an Agents funktioniert reibungslos – gleichzeitig ist unser CSAT spürbar gestiegen.",
    author: "Miriam K.",
    role: "Leiterin Kundenservice, Online-Händler",
  },
];

export const Testimonials = () => {
  return (
    <section id="stimmen" className="py-32 bg-secondary/20">
      <div className="container max-w-5xl">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8 }}
          className="text-center mb-20"
        >
          <h2 className="font-display text-4xl md:text-5xl lg:text-6xl font-bold tracking-tight">
            Kundenstimmen
          </h2>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-10 mb-16">
          {testimonials.map((testimonial, index) => (
            <motion.div
              key={testimonial.author}
              initial={{ opacity: 0, y: 40 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6, delay: index * 0.15 }}
              className="relative p-10 rounded-3xl bg-card/50 border border-border/30"
            >
              {/* Quote icon */}
              <Quote className="w-10 h-10 text-primary/30 mb-6" />

              {/* Stars */}
              <div className="flex gap-1 mb-6">
                {[...Array(5)].map((_, i) => (
                  <Star key={i} className="w-4 h-4 fill-primary text-primary" />
                ))}
              </div>

              <blockquote className="text-foreground text-lg mb-8 leading-relaxed font-light">
                „{testimonial.quote}"
              </blockquote>

              <div>
                <p className="font-semibold text-lg">{testimonial.author}</p>
                <p className="text-muted-foreground">{testimonial.role}</p>
              </div>
            </motion.div>
          ))}
        </div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5, delay: 0.3 }}
          className="text-center"
        >
          <ContactSheet 
            trigger={
              <Button variant="hero" size="lg" className="text-base px-8">
                Beratung anfragen
              </Button>
            }
          />
        </motion.div>
      </div>
    </section>
  );
};
