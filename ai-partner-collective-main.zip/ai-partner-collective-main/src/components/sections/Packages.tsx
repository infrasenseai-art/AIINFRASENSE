import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";
import { Sparkles, Zap, Shield, ArrowRight } from "lucide-react";

const packages = [
  {
    name: "Starter",
    icon: Sparkles,
    color: "text-accent",
    borderColor: "border-accent/30",
    features: [
      "Onboarding",
      "1 Basis-Workflow",
      "Standard-Templates & Quick-Replies",
      "E-Mail Support",
    ],
    cta: "Jetzt Termin buchen",
  },
  {
    name: "Growth",
    icon: Zap,
    color: "text-primary",
    borderColor: "border-primary",
    highlighted: true,
    features: [
      "Alles aus Starter",
      "KI-Antworten & Automatisierte Flows",
      "3 zusätzliche Workflows",
      "Monatliche Optimierung",
    ],
    cta: "Demo & Termin",
  },
  {
    name: "Enterprise",
    icon: Shield,
    color: "text-pink-400",
    borderColor: "border-pink-400/30",
    features: [
      "Individuelle Integrationen (ERP/CRM)",
      "Monitoring & Alarmierung",
      "Priorisierte Umsetzung",
      "Sicherheit & Compliance erweitert",
    ],
    cta: "Gespräch vereinbaren",
  },
];

export const Packages = () => {
  return (
    <section id="pakete" className="py-24">
      <div className="container">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="mb-16"
        >
          <h2 className="font-display text-4xl md:text-5xl font-bold mb-4">Pakete</h2>
          <p className="text-muted-foreground text-lg">
            Klar strukturierte Leistungspakete – transparent & erweiterbar.
          </p>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {packages.map((pkg, index) => (
            <motion.div
              key={pkg.name}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: index * 0.1 }}
              className={`glass-card rounded-xl p-8 border-2 ${pkg.borderColor} ${
                pkg.highlighted ? "animate-pulse-glow" : ""
              } transition-all duration-300`}
            >
              <div className="flex items-center gap-3 mb-6">
                <span className={`${pkg.color} font-semibold`}>{pkg.name}</span>
                <span className="text-muted-foreground">•</span>
                <pkg.icon className={`w-5 h-5 ${pkg.color}`} />
                <span className="text-muted-foreground text-sm">Paket</span>
              </div>

              <ul className="space-y-4 mb-8">
                {pkg.features.map((feature) => (
                  <li key={feature} className="flex items-start gap-2 text-muted-foreground">
                    <span className="text-foreground">•</span>
                    {feature}
                  </li>
                ))}
              </ul>

              <Button 
                variant={pkg.highlighted ? "hero" : "outline"} 
                className="w-full group"
              >
                {pkg.cta}
                <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
              </Button>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};
