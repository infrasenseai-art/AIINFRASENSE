import { motion } from "framer-motion";
import { Headphones, Settings2, Star } from "lucide-react";

const useCases = [
  {
    icon: Headphones,
    title: "Kundenservice",
    description: "Automatisches Routing, intelligente Antwortvorschläge und CSAT-Optimierung.",
  },
  {
    icon: Settings2,
    title: "Operations",
    description: "Ticket-Priorisierung, Eskalations-Workflows und proaktives Monitoring.",
  },
  {
    icon: Star,
    title: "Vertrieb",
    description: "Lead-Qualifizierung, automatisierte Follow-ups und CRM-Integration.",
  },
];

export const UseCases = () => {
  return (
    <section id="use-cases" className="py-32 bg-secondary/20">
      <div className="container max-w-6xl">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8 }}
          className="text-center mb-20"
        >
          <h2 className="font-display text-4xl md:text-5xl lg:text-6xl font-bold mb-6 tracking-tight">
            Anwendungsbereiche
          </h2>
          <p className="text-muted-foreground text-xl max-w-2xl mx-auto font-light">
            KI-Lösungen für verschiedene Unternehmensbereiche.
          </p>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {useCases.map((useCase, index) => (
            <motion.div
              key={useCase.title}
              initial={{ opacity: 0, y: 40 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6, delay: index * 0.15 }}
              className="text-center p-10"
            >
              <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-primary/10 text-primary mb-8">
                <useCase.icon className="w-8 h-8 stroke-[1.5]" />
              </div>

              <h3 className="font-display text-2xl font-semibold mb-4">{useCase.title}</h3>
              <p className="text-muted-foreground leading-relaxed font-light">
                {useCase.description}
              </p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};
